<?php
function databaseConnection()
{
    $servername = "localhost:3306";
    $username = "root";
    $password = "";

    $conn = mysqli_connect($servername, $username, $password, "restaurant_finder");


    mysqli_set_charset($conn, 'utf8');

    if (!$conn) {
        die("Connection failed");
    } else {
        return $conn;
    }

}

function getOwnerRestaurant($user_id)//bak buna birdaha
{
    $con = databaseConnection();

    $sql = "SELECT r.restaurant_id,r.restaurant_img,r.restaurant_name,r.restaurant_address,r.restaurant_phone,r.restaurant_quota,c.city_name FROM users as u,restaurants as r,cities as c WHERE c.city_id=r.restaurant_city AND u.user_id=r.restaurant_owner AND r.restaurant_owner=" . $user_id;

    $result = mysqli_query($con, $sql);

    if (mysqli_num_rows($result) > 0) {
        return $result;
    }

    mysqli_close($con);
}

function getRoles()
{
    $con = databaseConnection();

    $sql = "SELECT * FROM roles";

    $result = mysqli_query($con, $sql);

    if (mysqli_num_rows($result) > 0) {
        return $result;
    }

    mysqli_close($con);
}

function getCities()
{
    $con = databaseConnection();

    $sql = "SELECT * FROM cities";

    $result = mysqli_query($con, $sql);

    if (mysqli_num_rows($result) > 0) {
        return $result;
    }

    mysqli_close($con);
}

function getWaitingOwnersCheckedMail()
{
    $con = databaseConnection();

    $sql = "SELECT user_id,user_name,user_surname,user_phone,user_email,restaurant_name,restaurant_address,restaurant_phone,restaurant_quota,city_name FROM users as u,restaurants as r,cities as c WHERE r.restaurant_owner=u.user_id AND c.city_id=r.restaurant_city AND user_role=2 AND checkedMail=1 AND user_status=3 GROUP BY user_id";

    $result = mysqli_query($con, $sql);

    if (mysqli_num_rows($result) > 0) {
        return $result;
    }

    mysqli_close($con);
}

function getWaitingOwners()
{
    $con = databaseConnection();

    $sql = "SELECT user_id,user_name,user_surname,user_phone,user_email,restaurant_name,restaurant_address,restaurant_phone,restaurant_quota,city_name FROM users as u,restaurants as r,cities as c WHERE r.restaurant_owner=u.user_id AND c.city_id=r.restaurant_city AND user_role=2 AND checkedMail=0 AND user_status=3 GROUP BY user_id";

    $result = mysqli_query($con, $sql);

    if (mysqli_num_rows($result) > 0) {
        return $result;
    }

    mysqli_close($con);
}

function acceptOwner($ownerID)
{

    $con = databaseConnection();

    $_ownerID = mysqli_real_escape_string($con, $ownerID);

    $sql = "UPDATE users SET user_status=1 WHERE user_id=" . $_ownerID;

    if (mysqli_query($con, $sql)) {
        header('Location: organiseNewComers.php');
        setcookie("acceptSuccess", "acceptSuccess", time() + (2));
    } else {
        header('Location: organiseNewComers.php');
        setcookie("acceptError", "acceptError", time() + (2));
    }

    mysqli_close($con);

}

function rejectOwner($ownerID)
{

    $con = databaseConnection();

    $_ownerID = mysqli_real_escape_string($con, $ownerID);

    $sql = "DELETE FROM restaurants WHERE restaurant_owner=" . $_ownerID;

    if (mysqli_query($con, $sql)) {

        $sql2 = "DELETE FROM users WHERE user_id=" . $_ownerID;

        if (mysqli_query($con, $sql2)) {
            header('Location: organiseNewComers.php');
            setcookie("rejectSuccess", "rejectSuccess", time() + (2));
        } else {
            header('Location: organiseNewComers.php');
            setcookie("rejectError", "rejectError", time() + (2));
        }

    } else {
        header('Location: organiseNewComers.php');
        setcookie("rejectError", "rejectError", time() + (2));
    }

    mysqli_close($con);

}

function getRestaurantsByCity($cityID)
{

    $con = databaseConnection();

    $_cityID = mysqli_real_escape_string($con, $cityID);

    $sql = "SELECT r.restaurant_id,r.restaurant_img,r.restaurant_name,r.restaurant_address,r.restaurant_phone FROM restaurants as r,users as u WHERE r.restaurant_owner=u.user_id AND u.user_status=1 AND restaurant_city=" . $_cityID." ORDER BY r.restaurant_name ASC";

    $result = mysqli_query($con, $sql);

    $tmp_response = array();
    $actual_response = array();

    if (mysqli_num_rows($result) > 0) {
        $i = 0;
        $tmp_response["empty"] = 0;
        while ($row = mysqli_fetch_assoc($result)) {
            $tmp_response["restaurant_id"] = $row["restaurant_id"];
            $tmp_response["restaurant_img"] = $row["restaurant_img"];
            $tmp_response["restaurant_name"] = $row["restaurant_name"];
            $tmp_response["restaurant_address"] = $row["restaurant_address"];
            $tmp_response["restaurant_phone"] = $row["restaurant_phone"];
            $actual_response[$i] = $tmp_response;
            $i++;
        }
        echo json_encode($actual_response);
    } else {
        $tmp_response["empty"] = 1;
        $actual_response[0] = $tmp_response;
        echo json_encode($actual_response);
    }

    mysqli_close($con);

}

function getSearchResult($keyword)
{
    $con = databaseConnection();

    $_keyword = mysqli_real_escape_string($con, $keyword);

    $result = mysqli_query($con, "SELECT r.restaurant_id,r.restaurant_img,r.restaurant_name,r.restaurant_address,r.restaurant_phone,r.restaurant_quota,c.city_name FROM users as u,restaurants as r,cities as c WHERE u.user_id=r.restaurant_owner AND c.city_id=r.restaurant_city AND user_status=1 AND restaurant_quota > 0 AND (restaurant_name LIKE '%" . $_keyword . "%' OR city_name LIKE '%" . $_keyword . "%') GROUP BY r.restaurant_id ORDER BY r.restaurant_name ASC");

    $tmp_response = array();
    $actual_response = array();

    if (mysqli_num_rows($result) > 0) {
        $i = 0;
        $tmp_response["empty"] = 0;
        while ($row = mysqli_fetch_assoc($result)) {
            $tmp_response["restaurant_id"] = $row["restaurant_id"];
            $tmp_response["restaurant_img"] = $row["restaurant_img"];
            $tmp_response["restaurant_name"] = $row["restaurant_name"];
            $tmp_response["restaurant_address"] = $row["restaurant_address"];
            $tmp_response["restaurant_phone"] = $row["restaurant_phone"];
            $tmp_response["restaurant_quota"] = $row["restaurant_quota"];
            $tmp_response["restaurant_city"] = $row["city_name"];
            $actual_response[$i] = $tmp_response;
            $i++;
        }
        echo json_encode($actual_response);
    } else {
        $tmp_response["empty"] = 1;
        $actual_response[0] = $tmp_response;
        echo json_encode($actual_response);
    }

    mysqli_close($con);
}

function getMyReservations($guestEmail){ //id yerine mail kullanalım mail unique olduğu için rahat rahat bulunur.
    $con = databaseConnection();

    $_guestEmail = mysqli_real_escape_string($con,$guestEmail); 

    $sql = "SELECT rv.reservation_person_number,rv.reservation_date,rv.reservation_time,rv.reservation_message,r.restaurant_name,r.restaurant_address,r.restaurant_phone FROM reservations as rv,restaurants as r,users as u WHERE u.user_id=rv.reservation_owner AND rv.reservation_restaurant=r.restaurant_id AND u.user_email='".$_guestEmail."' GROUP BY rv.reservation_id ORDER BY rv.reservation_date DESC, rv.reservation_time DESC";

    $result = mysqli_query($con,$sql);

    if(mysqli_num_rows($result) > 0){
        return $result;
    }

    mysqli_close($con);
}

function getRestaurantReservations($ownerEmail){

    $con = databaseConnection();

    $_ownerEmail = mysqli_real_escape_string($con,$ownerEmail);

    $sql = "SELECT ur.user_name,ur.user_surname,ur.user_phone,ur.user_email,rv.reservation_person_number,rv.reservation_date,rv.reservation_time,rv.reservation_message FROM users as u,users as ur,restaurants as r,reservations as rv WHERE ur.user_id=rv.reservation_owner AND u.user_id=r.restaurant_owner AND r.restaurant_id=rv.reservation_restaurant AND (rv.reservation_date >= NOW()) AND u.user_email='".$_ownerEmail."' GROUP BY rv.reservation_id ORDER BY rv.reservation_date ASC, rv.reservation_time ASC";

    $result = mysqli_query($con,$sql);

    if(mysqli_num_rows($result) > 0){
        return $result;
    }

    mysqli_close($con);

}


function makeReservation($guestID, $restaurantID, $numberOfPeople, $reservationDate, $reservationTime, $reservationMessage)
{
    $con = databaseConnection();

    $result = mysqli_query($con, "SELECT restaurant_quota FROM restaurants WHERE restaurant_id=" . $restaurantID);

    $row = mysqli_fetch_assoc($result);

    $quota = $row["restaurant_quota"];

    if ($quota <= 0 || $quota < $numberOfPeople) {
        header('Location: mainPage.php');
        setcookie("noQuota", "noQuota", time() + (2));
    } else {
        $_reservationMessage = mysqli_real_escape_string($con, $reservationMessage);

        $sql = "UPDATE restaurants SET restaurant_quota = restaurant_quota - " . $numberOfPeople . " WHERE restaurant_id=" . $restaurantID;
        if (mysqli_query($con, $sql)) {
            $sql2 = "INSERT INTO reservations(reservation_person_number,reservation_date,reservation_time,reservation_message,reservation_owner,reservation_restaurant) VALUES ('" . $numberOfPeople . "','" . $reservationDate . "','" . $reservationTime . "','" . $_reservationMessage . "','" . $guestID . "','" . $restaurantID . "')";

            if (mysqli_query($con, $sql2)) {
                header('Location: mainPage.php');
                setcookie("successReservation", "successReservation", time() + (2));
            } else {
                $sql3 = "UPDATE restaurants SET restaurant_quota = restaurant_quota + " . $numberOfPeople;
                mysqli_query($con, $sql3);
                header('Location: mainPage.php');
                setcookie("failedReservation", "failedReservation", time() + (2));
            }
        } else {
            header('Location: mainPage.php');
            setcookie("failedReservation", "failedReservation", time() + (2));
        }
    }

    mysqli_close($con);
}

function registerGuest($userName, $userSurname, $userPhone, $userEmail, $userPass)
{
    require 'Mail/PHPMailerAutoload.php';
    include 'Mail/class.phpmailer.php';

    $key = md5(microtime() . rand());

    $con = databaseConnection();

    $_userName = mysqli_real_escape_string($con, $userName);
    $_userSurname = mysqli_real_escape_string($con, $userSurname);
    $_userPhone = mysqli_real_escape_string($con, $userPhone);
    $_userEmail = mysqli_real_escape_string($con, $userEmail);
    $_userPass = mysqli_real_escape_string($con, $userPass);

    $guvenliSha = sha1($_userPass);
    $guvenliMd = md5($guvenliSha);

    $result = mysqli_query($con, "SELECT user_email FROM users");

    $sameMail = 0;

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            if ($_userEmail == $row["user_email"]) {
                $sameMail = 1;
            }
        }
    }

    if ($sameMail === 0) {

        $sql = "INSERT INTO users(user_image,user_name,user_surname,user_phone,user_email,user_pass,user_role,user_status,activation_code) VALUES ('#','" . $_userName . "','" . $_userSurname . "','" . $_userPhone . "','" . $_userEmail . "','" . $guvenliMd . "','3','3','" . $key . "')";

        if (mysqli_query($con, $sql)) {
            $mail = new PHPMailer();
            $mail->IsSMTP();
            $mail->SMTPAuth = true;
            $mail->Host = 'smtp.gmail.com';
            $mail->Port = 587;
            $mail->SMTPSecure = 'tls';
            $mail->Username = 'restaurantfinder2016@gmail.com';
            $mail->Password = 'restaurant123';
            $mail->SetFrom($mail->Username, 'Restaurant Finder Activation');
            $mail->AddAddress($_userEmail, 'Restaurant Finder');
            $mail->CharSet = 'UTF-8';
            $mail->Subject = 'Restaurant Finder Activation';
            $mail->MsgHTML('You have created an account on Restaurant Finder successfully, only one thing to go, click that link for activate your account localhost/RestaurantFinder/mailCheck.php?role=guest&key=' . $key);
            if ($mail->Send()) {
                header('Location: loginPage.php');
                setcookie("registerSuccess", "registerSuccess", time() + (2));
            } else {
                header('Location: loginPage.php');
                setcookie("activationError", "activationError", time() + (2));
            }
        } else {
            header('Location: registerPage.php');
            setcookie("registerError", "registerError", time() + (2));
        }

    } elseif ($sameMail === 1) {
        header('Location: registerPage.php');
        setcookie("sameMail", "sameMail", time() + (2));
    }

    mysqli_close($con);

}

function registerOwner($userName, $userSurname, $userPhone, $userEmail, $userPass, $restaurantName, $restaurantAddress, $restaurantPhone, $restaurantQuota, $restaurantCity)
{
    require 'Mail/PHPMailerAutoload.php';
    include 'Mail/class.phpmailer.php';

    $key = md5(microtime() . rand());

    $con = databaseConnection();

    $_userName = mysqli_real_escape_string($con, $userName);
    $_userSurname = mysqli_real_escape_string($con, $userSurname);
    $_userPhone = mysqli_real_escape_string($con, $userPhone);
    $_userEmail = mysqli_real_escape_string($con, $userEmail);
    $_userPass = mysqli_real_escape_string($con, $userPass);

    $guvenliSha = sha1($_userPass);
    $guvenliMd = md5($guvenliSha);

    $result = mysqli_query($con, "SELECT user_email FROM users");

    $sameMail = 0;

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            if ($_userEmail == $row["user_email"]) {
                $sameMail = 1;
            }
        }
    }

    if ($sameMail === 0) {

        $sql = "INSERT INTO users(user_image,user_name,user_surname,user_phone,user_email,user_pass,user_role,user_status,activation_code) VALUES ('#','" . $_userName . "','" . $_userSurname . "','" . $_userPhone . "','" . $_userEmail . "','" . $guvenliMd . "','2','3','" . $key . "')";

        if (mysqli_query($con, $sql)) {

            $_restaurantName = mysqli_real_escape_string($con, $restaurantName);
            $_restaurantAddress = mysqli_real_escape_string($con, $restaurantAddress);
            $_restaurantPhone = mysqli_real_escape_string($con, $restaurantPhone);
            $_restaurantQuota = mysqli_real_escape_string($con, $restaurantQuota);
            $_restaurantCity = mysqli_real_escape_string($con, $restaurantCity);

            $addedUserResult = mysqli_query($con, "SELECT user_id FROM users WHERE user_email='" . $_userEmail . "'");

            $newUserId = 0;
            if (mysqli_num_rows($addedUserResult) > 0) {
                while ($rown = mysqli_fetch_assoc($addedUserResult)) {
                    $newUserId = $rown["user_id"];
                }
            }


            $sql2 = "INSERT INTO restaurants(restaurant_img,restaurant_name,restaurant_address,restaurant_phone,restaurant_quota,restaurant_owner,restaurant_city) VALUES ('#','" . $_restaurantName . "','" . $_restaurantAddress . "','" . $_restaurantPhone . "','" . $_restaurantQuota . "','" . $newUserId . "','" . $_restaurantCity . "')";

            if (mysqli_query($con, $sql2)) {
                $mail = new PHPMailer();
                $mail->IsSMTP();
                $mail->SMTPAuth = true;
                $mail->Host = 'smtp.gmail.com';
                $mail->Port = 587;
                $mail->SMTPSecure = 'tls';
                $mail->Username = 'restaurantfinder2016@gmail.com';
                $mail->Password = 'restaurant123';
                $mail->SetFrom($mail->Username, 'Restaurant Finder Activation');
                $mail->AddAddress($_userEmail, 'Restaurant Finder');
                $mail->CharSet = 'UTF-8';
                $mail->Subject = 'Restaurant Finder Activation';
                $mail->MsgHTML('You have created an restaurant owner account on Restaurant Finder successfully, click that link for activate your mail after then our crew will contact you as soon as possible localhost/RestaurantFinder/mailCheck.php?role=owner&key=' . $key);
                if ($mail->Send()) {
                    header('Location: loginPage.php');
                    setcookie("registerSuccess", "registerSuccess", time() + (2));
                } else {
                    header('Location: loginPage.php');
                    setcookie("activationError", "activationError", time() + (2));
                }
            }


        } else {
            header('Location: joinUs.php');
            setcookie("registerError", "registerError", time() + (2));
        }

    } elseif ($sameMail === 1) {
        header('Location: joinUs.php');
        setcookie("sameMail", "sameMail", time() + (2));
    }

    mysqli_close($con);

}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["joinName"]) && isset($_POST["joinSurname"]) && isset($_POST["joinPhone"]) && isset($_POST["joinEmail"]) && isset($_POST["joinPass"]) && isset($_POST["restName"]) && isset($_POST["restAddress"]) && isset($_POST["restPhone"]) && isset($_POST["restQuota"]) && isset($_POST["restCity"]) && isset($_POST["joinRegister"])) {
    $quota = 0;
    if (!empty($_POST["joinName"]) && !empty($_POST["joinSurname"]) && !empty($_POST["joinPhone"]) && !empty($_POST["joinEmail"]) && !empty($_POST["joinPass"])) {
        if (!empty($_POST["restName"]) && !empty($_POST["restAddress"]) && !empty($_POST["restPhone"]) && !empty($_POST["restCity"])) {
            if ($_POST["restQuota"] > 0) {
                $quota = $_POST["restQuota"];
            } else {
                $quota = 0;
            }

            registerOwner($_POST["joinName"], $_POST["joinSurname"], $_POST["joinPhone"], $_POST["joinEmail"], $_POST["joinPass"], $_POST["restName"], $_POST["restAddress"], $_POST["restPhone"], $quota, $_POST["restCity"]);

        } else {
            header('Location: joinUs.php');
            setcookie("emptyRest", "emptyRest", time() + (2));
        }
    } else {
        header('Location: joinUs.php');
        setcookie("emptyContact", "emptyContact", time() + (2));
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["registerName"]) && isset($_POST["registerSurname"]) && isset($_POST["registerPhone"]) && isset($_POST["registerEmail"]) && isset($_POST["registerPass"]) && isset($_POST["guestRegister"])) {

    if (!empty($_POST["registerName"]) && !empty($_POST["registerSurname"]) && !empty($_POST["registerPhone"]) && !empty($_POST["registerEmail"]) && !empty($_POST["registerPass"])) {

        registerGuest($_POST["registerName"], $_POST["registerSurname"], $_POST["registerPhone"], $_POST["registerEmail"], $_POST["registerPass"]);

    } else {
        header('Location: registerPage.php');
        setcookie("emptyFields", "emptyFields", time() + (2));
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["searchKey"])) {
    if (!empty($_POST["searchKey"])) {
        getSearchResult($_POST["searchKey"]);
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["restID"]) && isset($_POST["reservationOwnerMail"]) && isset($_POST["numberPeople"]) && isset($_POST["reservationDate"]) && isset($_POST["reservationTime"]) && isset($_POST["reservationMessage"]) && isset($_POST["completeReservation"])) {
    $message = "";
    if (!empty($_POST["reservationMessage"])) {
        $message = $_POST["reservationMessage"];
    } else {
        $message = "No extra message.";
    }

    $date = date('Y-m-d', strtotime(str_replace('-', '/', $_POST["reservationDate"])));

    $guestId = 0;

    $con = databaseConnection();

    $result = mysqli_query($con, "SELECT user_id FROM users WHERE user_email='" . $_POST["reservationOwnerMail"] . "'");

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $guestId = $row["user_id"];
        }
    }

    makeReservation($guestId, $_POST["restID"], $_POST["numberPeople"], $date, $_POST["reservationTime"], $message);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["cityIdForRestaurant"])) {
    getRestaurantsByCity($_POST["cityIdForRestaurant"]);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["personId"]) && isset($_POST["acceptPerson"])) {
    acceptOwner($_POST["personId"]);
} elseif ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["personId"]) && isset($_POST["rejectPerson"])) {
    rejectOwner($_POST["personId"]);
}