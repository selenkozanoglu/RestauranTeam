<?php
include "functions.php";
session_start();

$cities = getCities();
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8">
    <script src="js/jquery-1.12.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/restaurant-finder.css">
    <title>Restaurant Finder</title>
</head>
<body>
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#">Restaurant Finder</a>
        </div>
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li><a href="mainPage.php">MainPage</a></li>
                <li><a href="businessPartners.php">Business Partners</a></li>
                <li class="active"><a href="joinUs.php">Join Us</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php
                if (isset($_SESSION["logged_user_name"]) && isset($_SESSION["logged_user_email"]) && isset($_SESSION["logged_user_role"])) {
                    $personalPageLink = "#";
                    switch ($_SESSION["logged_user_role"]) {
                        case "admin":
                            $personalPageLink = "adminPage.php";
                            break;
                        case "owner":
                            $personalPageLink = "ownerPage.php";
                            break;
                        case "guest":
                            $personalPageLink = "guestPage.php";
                            break;
                    }
                    ?>
                    <li>
                        <a href="<?php echo $personalPageLink; ?>"><span class="glyphicon glyphicon-user"></span>
                            Welcome <b> <?php echo $_SESSION["logged_user_name"] ?></b></a>
                    </li>
                    <li>
                        <a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Çıkış</a>
                    </li>
                    <?php
                } else {
                    ?>
                    <li>
                        <a href="loginPage.php"><span class="glyphicon glyphicon-log-in"></span> Login </a>
                    </li>
                    <li>
                        <a href="registerPage.php"><span class="glyphicon glyphicon-edit"></span> Register </a>
                    </li>
                    <?php
                }
                ?>
            </ul>
        </div>
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
    </div>
</nav>

<div class="container">
    <div class="container-fluid">

        <?php if (isset($_COOKIE['emptyContact'])) { ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Please fill the necessary contact informations correctly.</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['emptyRest'])) { ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Please fill the necessary restaurant informations correctly.</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['sameMail'])) { ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>There is another account belong to this email, if you already registered you can use <a href="loginPage.php">login page</a> for entering system.</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['registerError'])) { ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Oops! Sorry something went wrong, please try again :( .</strong>
            </div>
        <?php } ?>

        <div class="row">
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" role="form"
                  onsubmit="return passCheck()">
                <div class="col-lg-4">
                    <div class="page-header h4">
                        Contact Person Informations
                    </div>
                    <div class="card-view">
                        <div class="form-group">
                            <label for="joinName">Name(*):</label>
                            <input required type="text" class="form-control" name="joinName" id="joinName">
                        </div>
                        <div class="form-group">
                            <label for="joinSurname">Surname(*):</label>
                            <input required type="text" class="form-control" name="joinSurname" id="joinSurname">
                        </div>
                        <div class="form-group">
                            <label for="joinPhone">Phone(*):</label>
                            <input min="0" required type="number" class="form-control" name="joinPhone" id="joinPhone">
                        </div>
                        <div class="form-group">
                            <label for="joinEmail">E-mail(*):</label>
                            <input required type="email" class="form-control" name="joinEmail" id="joinEmail">
                        </div>
                        <div class="form-group">
                            <label for="joinPass">Password(*):</label>
                            <input minlength="5" required type="password" class="form-control" name="joinPass" id="joinPass">
                        </div>
                        <div class="form-group" id="rePass">
                            <label for="joinPassRe">Re-type Password:</label>
                            <input required type="password" class="form-control" name="joinPassRe" id="joinPassRe">
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="page-header h4">
                        Restaurant Informations
                    </div>
                    <div class="card-view">
                        <div class="form-group">
                            <label for="restName">Name(*):</label>
                            <input required type="text" class="form-control" name="restName" id="restName">
                        </div>
                        <div class="form-group">
                            <label for="restAddress">Address(*):</label>
                            <input required type="text" class="form-control" name="restAddress" id="restAddress">
                        </div>
                        <div class="form-group">
                            <label for="restPhone">Phone(*):</label>
                            <input min="0" required type="number" class="form-control" name="restPhone" id="restPhone">
                        </div>
                        <div class="form-group">
                            <label for="restQuota">Quota(Optional):</label>
                            <input min="0" type="number" class="form-control" name="restQuota" id="restQuota">
                        </div>
                        <div class="form-group">
                            <label for="restCity">City:</label>
                            <select class="form-control" name="restCity" id="restCity">
                                <?php
                                if ($cities != null) {
                                    while ($row = mysqli_fetch_assoc($cities)) {
                                        ?>
                                        <option
                                            value="<?php echo $row["city_id"]; ?>"><?php echo $row["city_name"]; ?></option>
                                        <?php
                                    }
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group card-buton text-center">
                        <input type="submit" name="joinRegister" class="btn btn-primary" value="Complete Registration">
                    </div>
                </div>
            </form>
        </div>


    </div>
</div>
<script>
    function passCheck() {
        var pass1 = document.getElementById("joinPass").value;
        var pass2 = document.getElementById("joinPassRe").value;
        var ok = true;
        if (pass1 != pass2) {
            document.getElementById("rePass").className += ' has-error';
            ok = false;
        }
        return ok;
    }
</script>
</body>
</html>