<?php

$email = $pwd = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["userEmail"]) && isset($_POST["userPassword"]) && isset($_POST["roleList"]) && !empty($_POST["userEmail"]) && !empty($_POST["userPassword"])) {
    $email = test_input($_POST["userEmail"]);
    $pwd = test_input($_POST["userPassword"]);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header('Location: loginPage.php');
        setcookie("invalidMail", "invalidMail", time() + (1));
        exit();
    }

    $role = $_POST["roleList"];

    if($role === 0){
        header('Location: loginPage.php');
        setcookie("roleError", "roleError", time() + (1));
        exit();
    }


    $guvenlishaSifre = sha1($pwd);
    $guvenliMdSifre = md5($guvenlishaSifre);

    $servername = "localhost:3306";
    $username = "root";
    $password = "";
    $conn = mysqli_connect($servername, $username, $password, "restaurant_finder");

    mysqli_set_charset($conn, 'utf8');

    $sql = "SELECT u.user_name,u.user_email,r.role_name FROM users as u,roles as r WHERE u.user_email='" . $email . "' AND u.user_pass='" . $guvenliMdSifre . "' AND u.user_role='".$role."' AND u.user_status=1 AND u.user_role = r.role_id";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        ob_start();
        session_start();
        $row = mysqli_fetch_assoc($result);
        $_SESSION["logged_user_name"] = $row["user_name"];
        $_SESSION["logged_user_email"] = $row["user_email"];
        $_SESSION["logged_user_role"] = $row["role_name"];
        if($_SESSION["logged_user_role"] === "admin"){
            header('Location: adminPage.php');
        }elseif ($_SESSION["logged_user_role"] === "owner"){
            header('Location: ownerPage.php');
        }elseif ($_SESSION["logged_user_role"] === "guest"){
            header('Location: guestPage.php');
        }

        ob_end_flush();
    } else {
        header('Location: loginPage.php');
        setcookie("noUser", "noUser", time() + (1));
    }

    $conn->close();

} else {
    header('Location: loginPage.php');
    setcookie("emptyData", "emptyData", time() + (1));
}



function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}


