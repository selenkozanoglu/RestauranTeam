<?php
include "functions.php";
session_start();
if (isset($_SESSION["logged_user_role"])) {
    switch ($_SESSION["logged_user_role"]) {
        case "admin":
            header('Location: adminPage.php');
            break;
        case "owner":
            header('Location: ownerPage.php');
            break;
        case "guest":
            header('Location: guestPage.php');
            break;
    }
}

$roles = getRoles();
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8">
    <script src="js/jquery-1.12.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/restaurant-finder.css">
    <title>Restaurant Finder</title>
</head>
<body>
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#">Restaurant Finder</a>
        </div>
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li><a href="mainPage.php">MainPage</a></li>
                <li><a href="businessPartners.php">Business Partners</a></li>
                <li><a href="joinUs.php">Join Us</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li class="active">
                    <a href="loginPage.php"><span class="glyphicon glyphicon-log-in"></span> Login </a>
                </li>
                <li>
                    <a href="registerPage.php"><span class="glyphicon glyphicon-edit"></span> Register </a>
                </li>
            </ul>
        </div>
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
    </div>
</nav>

<div class="container">
    <div class="container-fluid">

        <?php if (isset($_COOKIE['loginFirst'])) { ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Before using system, you should login first.</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['pleaseLogin'])) { ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>For make a reservation, you should login first.</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['noUser'])) { ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>E-mail or password is wrong. Also control your account type selected correct.</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['emptyData'])) { ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Please fill necessary fields.</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['registerSuccess'])) { ?>
            <div class="alert alert-success fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Registration was done succesfully, please check your e-mail and activate your account. After your activation you use here for login.</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['loggedOut'])) { ?>
            <div class="alert alert-success fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>You have been logged out safely.</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['notGeneratedUs'])) { ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>This is a broken link, please use an official generated link.</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['alreadyCheckedOwner'])) { ?>
            <div class="alert alert-warning fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>This e-mail is already approved, please wait our crew's call for activating your account, thank you for your patience.</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['alreadyChecked'])) { ?>
            <div class="alert alert-warning fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>This e-mail is already approved, you can log in succesfully with your e-mail and password.</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['justCheckedOwner'])) { ?>
            <div class="alert alert-success fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Congratulations! Your e-mail was approved succesfully, our crew will call you as soon as possible after than you can use our system with this e-mail and password.</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['justChecked'])) { ?>
            <div class="alert alert-success fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Congratulations! Your e-mail was approved succesfully, you can start making reservations from our system. Just login with your e-mail and password from this page.</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['tryAgain'])) { ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Oops! Something went wrong, please try again. If problem is continued, please inform us from <a href="contactUs.php">Contact Page</a>.</strong>
            </div>
        <?php } ?>

        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="card-view">
                    <form action="login.php" method="post" role="form">
                        <div class="form-group">
                            <label class="pull-left" for="userEmail">Enter your e-mail:</label>
                            <input type="email" required name="userEmail" id="userEmail" class="form-control"
                                   placeholder="example@example.com">
                        </div>
                        <div class="form-group">
                            <label class="pull-left" for="userPassword">Enter your password:</label>
                            <input type="password" required name="userPassword" id="userPassword" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="roleList">Select your account type:</label>
                            <select class="form-control" name="roleList" id="roleList">
                                <?php
                                if ($roles != null) {
                                    while ($row = mysqli_fetch_assoc($roles)) {
                                        ?>
                                        <option
                                            value="<?php echo $row["role_id"]; ?>"><?php echo $row["role_name"]; ?></option>
                                        <?php
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group pull-right">
                            <input type="submit" name="tryLogin" class="btn btn-primary" value="Login">
                        </div>
                    </form>
                </div>
            </div>
        </div>


    </div>
</div>
</body>
</html>