<?php
session_start();
ob_start();
unset($_SESSION["logged_user_name"]);
unset($_SESSION["logged_user_email"]);
unset($_SESSION["logged_user_role"]);
setcookie("loggedOut", "loggedOut", time() + (2));
header("Refresh: 1; url=loginPage.php");
ob_end_flush();
