<?php
function databaseConnection()
{
    $servername = "localhost:3306";
    $username = "root";
    $password = "";

    $conn = mysqli_connect($servername, $username, $password, "restaurant_finder");


    mysqli_set_charset($conn, 'utf8');

    if (!$conn) {
        die("Connection failed");
    } else {
        return $conn;
    }

}

function activateGuest($GuestKey)
{
    $con = databaseConnection();

    $alreadyActive = false;

    $currentActive = mysqli_query($con, "SELECT user_status FROM users WHERE activation_code='" . $GuestKey."'");

    if (mysqli_num_rows($currentActive) > 0) {
        while ($row = mysqli_fetch_assoc($currentActive)) {
            if ($row["user_status"] == 1) {
                $alreadyActive = true;
            }
        }
    }

    if ($alreadyActive) {
        header('Location: loginPage.php');
        setcookie("alreadyChecked", "alreadyChecked", time() + (2));
    } else {
        if (mysqli_query($con, "UPDATE users SET user_status=1,checkedMail=1 WHERE activation_code='" . $GuestKey."'")) {
            header('Location: loginPage.php');
            setcookie("justChecked", "justChecked", time() + (2));
        } else {
            header('Location: loginPage.php');
            setcookie("tryAgain", "tryAgain", time() + (2));
        }


    }

    mysqli_close($con);


}

function checkOwnersMail($OwnerKey)
{

    $con = databaseConnection();

    $alreadyActive = false;

    $currentActive = mysqli_query($con, "SELECT checkedMail FROM users WHERE activation_code=" . $OwnerKey);

    if (mysqli_num_rows($currentActive) > 0) {
        while ($row = mysqli_fetch_assoc($currentActive)) {
            if ($row["checkedMail"] == 1) {
                $alreadyActive = true;
            }
        }
    }

    if ($alreadyActive) {
        header('Location: loginPage.php');
        setcookie("alreadyCheckedOwner", "alreadyCheckedOwner", time() + (2));
    } else {
        if (mysqli_query($con, "UPDATE users SET checkedMail=1 WHERE activation_code='" . $OwnerKey."'")) {
            header('Location: loginPage.php');
            setcookie("justCheckedOwner", "justCheckedOwner", time() + (2));
        } else {
            header('Location: loginPage.php');
            setcookie("tryAgain", "tryAgain", time() + (2));
        }


    }

    mysqli_close($con);

}

if (isset($_GET["role"]) && isset($_GET["key"]) && !empty($_GET["role"]) && !empty($_GET["key"])) {
    $con = databaseConnection();

    $role = mysqli_real_escape_string($con, $_GET["role"]);
    $key = mysqli_real_escape_string($con, $_GET["key"]);

    $result = mysqli_query($con, "SELECT r.role_name FROM users as u,roles as r WHERE u.user_role=r.role_id AND activation_code='" . $key."'");

    $row = mysqli_fetch_assoc($result);

    if ($role === $row["role_name"]) {
        if ($role == "owner") {
            checkOwnersMail($key);
        } elseif ($role == "guest") {
            activateGuest($key);
        }
    } else {
        header('Location: loginPage.php');
        setcookie("notGeneratedUs", "notGeneratedUs", time() + (2));
    }

}