<?php
include "functions.php";
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8">
    <script src="js/jquery-1.12.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/restaurant-finder.css">
    <title>Restaurant Finder</title>
</head>
<body>
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#">Restaurant Finder</a>
        </div>
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li class="active"><a href="mainPage.php">MainPage</a></li>
                <li><a href="businessPartners.php">Business Partners</a></li>
                <li><a href="joinUs.php">Join Us</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php
                if (isset($_SESSION["logged_user_name"]) && isset($_SESSION["logged_user_email"]) && isset($_SESSION["logged_user_role"])) {
                    $personalPageLink = "#";
                    switch ($_SESSION["logged_user_role"]) {
                        case "admin":
                            $personalPageLink = "adminPage.php";
                            break;
                        case "owner":
                            $personalPageLink = "ownerPage.php";
                            break;
                        case "guest":
                            $personalPageLink = "guestPage.php";
                            break;
                    }
                    ?>
                    <li>
                        <a href="<?php echo $personalPageLink; ?>"><span class="glyphicon glyphicon-user"></span>
                            Welcome <b> <?php echo $_SESSION["logged_user_name"] ?></b></a>
                    </li>
                    <li>
                        <a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Çıkış</a>
                    </li>
                    <?php
                } else {
                    ?>
                    <li>
                        <a href="loginPage.php"><span class="glyphicon glyphicon-log-in"></span> Login </a>
                    </li>
                    <li>
                        <a href="registerPage.php"><span class="glyphicon glyphicon-edit"></span> Register </a>
                    </li>
                    <?php
                }
                ?>
            </ul>
        </div>
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
    </div>
</nav>
<div class="container">
    <div class="container-fluid">

        <?php if (isset($_COOKIE['wrongUserType'])) { ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>For making reservations you need a guest account, please logout and create a personal guest
                    account.</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['forbiddenPage'])) { ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>This page is forbidden for your account type, please click your username for entering your own
                    page.</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['selectRestaurant'])) { ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Before make a reservation you should select a restaurant, please search and find a restaurant
                    then click 'Make Reservation' button.</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['successReservation'])) { ?>
            <div class="alert alert-success fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Your reservation received successfully, thank you for using our system.</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['failedReservation'])) { ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Oops! Something went wrong, we are sorry but you need to try again :(</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['noQuota'])) { ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Restaurant's quota is unavailable, may be somebody act quickly :/ </strong>
            </div>
        <?php } ?>


        <div class="row">
            <div class="col-lg-12">
                <div class="form-group">
                    <label for="searchRestaurants"><span class="glyphicon glyphicon-search"></span> Find A
                        Restaurant</label>
                    <input class="form-control" type="text" name="searchRestaurants" id="searchRestaurants"
                           onkeypress="getRestaurant();"
                           placeholder="Type a restaurant name or city for searching..">
                </div>
            </div>
        </div>

        <div id='editDiv' class="row">

        </div>


    </div>
</div>

<script>
    function getRestaurant() {
        var keyWordInput = document.getElementById("searchRestaurants");
        var keyWord = keyWordInput.value;
        var postD = {searchKey: keyWord};
        $.ajax({
            type: 'POST',
            url: 'functions.php',
            data: postD,
            dataType: 'text',
            success: function (resultData) {
                var jsonData = JSON.parse(resultData);
                for (var i = 0; i < jsonData.length; i++) {
                    var opt = jsonData[i];
                    if (opt.empty == 1) {
                        document.getElementById("editDiv").innerHTML = "<div class='container-fluid'> <b>Sorry, we can't find a restaurant for you :( </b></div>";
                    } else {
                        if (i == 0) {
                            document.getElementById("editDiv").innerHTML = "<div class='col-lg-12 text-center'>" +
                                "<div class='card-view img-responsive'>" +
                                "<div class='col-lg-4'>" +
                                "<div class='h3'>" + opt.restaurant_name + "</div>" +
                                "<img style='margin-top: 10px; max-height: 350px;' src='Restaurant-Images/exImg.jpg'class='thumbnail img-responsive' id='restaurantImg'>" +
                                "</div>" +
                                "<div class='col-lg-4'>" +
                                "<div class='h3'>Address Information</div>" +
                                "<p class='text-left'>" + opt.restaurant_address + "</p>" +
                                "</div>" +
                                "<div class='col-lg-4'>" +
                                "<div class='h3'>Quota: " + opt.restaurant_quota + "</div>" +
                                "<div class='h3'>Phone: " + opt.restaurant_phone + "</div>" +
                                "<div class='h3'>City: " + opt.restaurant_city + "</div>" +
                                "</div>" +
                                "<form method='post' action='reservationPage.php' role='form'> " +
                                "<input type='hidden' name='selectedResID' value='" + opt.restaurant_id + "'>" +
                                "<input type='hidden' name='selectedResName' value='" + opt.restaurant_name + "'>" +
                                "<div class='form-group'>" +
                                "<input class='btn btn-primary form-control' type='submit' name='makeReservation' id='makeReservation' value='Make Reservation'></div></form></div></div>";
                        } else if (i > 0) {
                            document.getElementById("editDiv").innerHTML += "<div class='col-lg-12 text-center'>" +
                                "<div class='card-view img-responsive'>" +
                                "<div class='col-lg-4'>" +
                                "<div class='h3'>" + opt.restaurant_name + "</div>" +
                                "<img style='margin-top: 10px; max-height: 350px;' src='Restaurant-Images/exImg.jpg'class='thumbnail img-responsive' id='restaurantImg'>" +
                                "</div>" +
                                "<div class='col-lg-4'>" +
                                "<div class='h3'>Address Information</div>" +
                                "<p class='text-left'>" + opt.restaurant_address + "</p>" +
                                "</div>" +
                                "<div class='col-lg-4'>" +
                                "<div class='h3'>Quota: " + opt.restaurant_quota + "</div>" +
                                "<div class='h3'>Phone: " + opt.restaurant_phone + "</div>" +
                                "<div class='h3'>City: " + opt.restaurant_city + "</div>" +
                                "</div>" +
                                "<form method='post' action='reservationPage.php' role='form'> " +
                                "<input type='hidden' name='selectedResID' value='" + opt.restaurant_id + "'>" +
                                "<input type='hidden' name='selectedResName' value='" + opt.restaurant_name + "'>" +
                                "<div class='form-group'>" +
                                "<input class='btn btn-primary form-control' type='submit' name='makeReservation' id='makeReservation' value='Make Reservation'></div></form></div></div>";
                        }
                    }

                }

            }
        });
    }
</script>
</body>
</html>