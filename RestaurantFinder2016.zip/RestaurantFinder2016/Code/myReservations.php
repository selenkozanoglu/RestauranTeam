<?php
include "functions.php";
session_start();
if (isset($_SESSION["logged_user_role"])) {
    switch ($_SESSION["logged_user_role"]) {
        case "owner":
            header('Location: mainPage.php');
            setcookie("forbiddenPage", "forbiddenPage", time() + (2));
            break;
        case "admin":
            header('Location: mainPage.php');
            setcookie("forbiddenPage", "forbiddenPage", time() + (2));
            break;
    }
} elseif (!isset($_SESSION["logged_user_role"])) {
    header('Location: loginPage.php');
    setcookie("loginFirst", "loginFirst", time() + (2));
}

$myReservations = getMyReservations($_SESSION["logged_user_email"]);

?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8">
    <script src="js/jquery-1.12.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/restaurant-finder.css">
    <title>Restaurant Finder</title>
</head>
<body>
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#">Restaurant Finder</a>
        </div>
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li><a href="mainPage.php">MainPage</a></li>
                <li class="active"><a href="myReservations.php">My Reservations</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php
                if (isset($_SESSION["logged_user_name"]) && isset($_SESSION["logged_user_email"]) && isset($_SESSION["logged_user_role"])) {
                    $personalPageLink = "#";
                    switch ($_SESSION["logged_user_role"]) {
                        case "admin":
                            $personalPageLink = "adminPage.php";
                            break;
                        case "owner":
                            $personalPageLink = "ownerPage.php";
                            break;
                        case "guest":
                            $personalPageLink = "guestPage.php";
                            break;
                    }
                    ?>
                    <li>
                        <a href="<?php echo $personalPageLink; ?>"><span class="glyphicon glyphicon-user"></span>
                            Welcome <b> <?php echo $_SESSION["logged_user_name"] ?></b></a>
                    </li>
                    <li>
                        <a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Çıkış</a>
                    </li>
                    <?php
                }
                ?>
            </ul>
        </div>
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
    </div>
</nav>
<div class="container">
    <div class="container-fluid">


        <div class="page-header">
            <h2>Reservation History</h2>
        </div>

        <?php
        if ($myReservations != null) {
            while ($row = mysqli_fetch_assoc($myReservations)) {
                ?>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card-view">
                            <div class="col-lg-4">
                                <div class="h3">
                                    <?php echo $row["restaurant_name"]; ?>
                                </div>
                                <img style="margin-top: 10px; max-height: 350px;" src="Restaurant-Images/exImg.jpg"
                                     class="thumbnail img-responsive" id="restaurantImg">
                            </div>
                            <div class="col-lg-4">
                                <div class="h3 col-lg-offset-0">
                                    Restaurant Address
                                </div>
                                <div class="col-lg-offset-0">
                                    <?php echo $row["restaurant_address"]; ?>
                                </div>
                                <div class="col-lg-offset-0">
                                    <div class="h4">
                                        Phone Number: <?php echo $row["restaurant_phone"]; ?>
                                    </div>
                                </div>
                                <div class="col-lg-offset-0">
                                    <div class="h4">
                                        Details: <?php echo $row["reservation_message"]; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="h3 col-lg-offset-0">
                                    <?php
                                    $mysqlDate = strtotime($row["reservation_date"]);
                                    $normalDate = date("m/d/Y",$mysqlDate);
                                    ?>
                                    Date: <?php echo $normalDate; ?>
                                </div>
                                <div class="h3 col-lg-offset-0">
                                    <?php
                                    $time = intval($row["reservation_time"]);
                                    $timePeriod = $time.":00 - ".($time+1).":00";
                                    ?>
                                    Time: <?php echo $timePeriod; ?>
                                </div>
                                <div class="h3 col-lg-offset-0">
                                    How Many People: <?php echo $row["reservation_person_number"]; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
            }
        } else {
            ?>
            <div class="h4">There is no reservation yet :(</div>
            <?php
        }
        ?>


    </div>
</div>
</body>
</html>