<?php
include "functions.php";
session_start();
if (isset($_SESSION["logged_user_role"])) {
    switch ($_SESSION["logged_user_role"]) {
        case "owner":
            header('Location: mainPage.php');
            setcookie("forbiddenPage", "forbiddenPage", time() + (2));
            break;
        case "guest":
            header('Location: mainPage.php');
            setcookie("forbiddenPage", "forbiddenPage", time() + (2));
            break;
    }
} elseif (!isset($_SESSION["logged_user_role"])) {
    header('Location: loginPage.php');
    setcookie("loginFirst", "loginFirst", time() + (2));
}

$checkedUsers = getWaitingOwnersCheckedMail();
$unCheckedUsers = getWaitingOwners();
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8">
    <script src="js/jquery-1.12.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/restaurant-finder.css">
    <title>Restaurant Finder</title>
</head>
<body>
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#">Restaurant Finder</a>
        </div>
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li><a href="mainPage.php">MainPage</a></li>
                <li class="active"><a href="organiseNewComers.php">Organise New Comers</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php
                if (isset($_SESSION["logged_user_name"]) && isset($_SESSION["logged_user_email"]) && isset($_SESSION["logged_user_role"])) {
                    $personalPageLink = "#";
                    switch ($_SESSION["logged_user_role"]) {
                        case "admin":
                            $personalPageLink = "adminPage.php";
                            break;
                        case "owner":
                            $personalPageLink = "ownerPage.php";
                            break;
                        case "guest":
                            $personalPageLink = "guestPage.php";
                            break;
                    }
                    ?>
                    <li>
                        <a href="<?php echo $personalPageLink; ?>"><span class="glyphicon glyphicon-user"></span>
                            Welcome <b> <?php echo $_SESSION["logged_user_name"] ?></b></a>
                    </li>
                    <li>
                        <a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Çıkış</a>
                    </li>
                    <?php
                }
                ?>
            </ul>
        </div>
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
    </div>
</nav>
<div class="container">
    <div class="container-fluid">

        <?php if (isset($_COOKIE['rejectSuccess'])) { ?>
            <div class="alert alert-success fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Restaurant owner was rejected and deleted from system successfully.</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['rejectError'])) { ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Oops! Something went wrong, please try again. If it goes like this please contact with system
                    administrator.</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['acceptSuccess'])) { ?>
            <div class="alert alert-success fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Restaurant owner was accepted successfully.</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['acceptError'])) { ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Oops! Something went wrong, please try again.</strong>
            </div>
        <?php } ?>

        <div class="page-header">
            <h2>Organise Waiting Owner Accounts</h2>
        </div>
        <div class="col-lg-6">
            <div class="page-header">
                <h4>Requests With Verificated E-Mail</h4>
            </div>


            <?php
            if ($checkedUsers != null) {
                while ($row = mysqli_fetch_assoc($checkedUsers)) {
                    ?>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="card-view">
                                <div class="h4">
                                    Contact Informations
                                </div>
                                <div class="row">
                                    <div class="col-lg-offset-1 col-xs-offset-1">
                                        <b>Name:</b> <?php echo $row["user_name"]; ?>
                                    </div>
                                    <div class="col-lg-offset-1 col-xs-offset-1">
                                        <b>Surname:</b> <?php echo $row["user_surname"]; ?>
                                    </div>
                                    <div class="col-lg-offset-1 col-xs-offset-1">
                                        <b>Phone:</b> <?php echo $row["user_phone"]; ?>
                                    </div>
                                    <div class="col-lg-offset-1 col-xs-offset-1">
                                        <b>E-mail:</b> <?php echo $row["user_email"]; ?>
                                    </div>
                                </div>

                                <div class="h4">
                                    Restaurant Informations
                                </div>
                                <div class="row">
                                    <div class="col-lg-offset-1 col-xs-offset-1">
                                        <b>Name:</b> <?php echo $row["restaurant_name"]; ?>
                                    </div>
                                    <div class="col-lg-offset-1 col-xs-offset-1">
                                        <b>Address:</b> <?php echo $row["restaurant_address"]; ?>
                                    </div>
                                    <div class="col-lg-offset-1 col-xs-offset-1">
                                        <b>Phone:</b> <?php echo $row["restaurant_phone"]; ?>
                                    </div>
                                    <div class="col-lg-offset-1 col-xs-offset-1">
                                        <b>Quota:</b> <?php echo $row["restaurant_quota"]; ?>
                                    </div>
                                    <div class="col-lg-offset-1 col-xs-offset-1">
                                        <b>City:</b> <?php echo $row["city_name"]; ?>
                                    </div>
                                </div>
                                <form action="functions.php" method="post" role="form">
                                    <div class="form-group card-buton">
                                        <input type="hidden" name="personId" value="<?php echo $row["user_id"]; ?>">
                                        <input class="btn btn-danger form-control" type="submit" name="rejectPerson"
                                               id="rejectPerson"
                                               value="Reject">
                                        <input class="btn btn-primary form-control" type="submit" name="acceptPerson"
                                               id="acceptPerson"
                                               value="Accept">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php

                }
            } else {
                ?>
                <b>There is no waiting user.</b>
                <?php
            }
            ?>

        </div>
        <div class="col-lg-6">
            <div class="page-header">
                <h4>Waiting For E-mail Verification</h4>
            </div>

            <?php
            if ($unCheckedUsers != null) {
                while ($row = mysqli_fetch_assoc($unCheckedUsers)) {
                    ?>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="card-view">
                                <div class="h4">
                                    Contact Informations
                                </div>
                                <div class="row">
                                    <div class="col-lg-offset-1 col-xs-offset-1">
                                        <b>Name:</b> <?php echo $row["user_name"]; ?>
                                    </div>
                                    <div class="col-lg-offset-1 col-xs-offset-1">
                                        <b>Surname:</b> <?php echo $row["user_surname"]; ?>
                                    </div>
                                    <div class="col-lg-offset-1 col-xs-offset-1">
                                        <b>Phone:</b> <?php echo $row["user_phone"]; ?>
                                    </div>
                                    <div class="col-lg-offset-1 col-xs-offset-1">
                                        <b>E-mail:</b> <?php echo $row["user_email"]; ?>
                                    </div>
                                </div>

                                <div class="h4">
                                    Restaurant Informations
                                </div>
                                <div class="row">
                                    <div class="col-lg-offset-1 col-xs-offset-1">
                                        <b>Name:</b> <?php echo $row["restaurant_name"]; ?>
                                    </div>
                                    <div class="col-lg-offset-1 col-xs-offset-1">
                                        <b>Address:</b> <?php echo $row["restaurant_address"]; ?>
                                    </div>
                                    <div class="col-lg-offset-1 col-xs-offset-1">
                                        <b>Phone:</b> <?php echo $row["restaurant_phone"]; ?>
                                    </div>
                                    <div class="col-lg-offset-1 col-xs-offset-1">
                                        <b>Quota:</b> <?php echo $row["restaurant_quota"]; ?>
                                    </div>
                                    <div class="col-lg-offset-1 col-xs-offset-1">
                                        <b>City:</b> <?php echo $row["city_name"]; ?>
                                    </div>
                                </div>
                                <form action="functions.php" method="post" role="form">
                                    <div class="form-group card-buton">
                                        <input type="hidden" name="personId" value="<?php echo $row["user_id"]; ?>">
                                        <input class="btn btn-danger form-control" type="submit" name="rejectPerson"
                                               id="rejectPerson"
                                               value="Reject">
                                        <input class="btn btn-primary form-control" type="submit" name="acceptPerson"
                                               id="acceptPerson"
                                               value="Accept">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php

                }
            } else {
                ?>
                <b>There is no waiting user.</b>
                <?php
            }
            ?>


        </div>

    </div>
</div>
</body>
</html>