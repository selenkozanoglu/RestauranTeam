<?php
include "functions.php";
session_start();
if (isset($_SESSION["logged_user_role"])) {
    switch ($_SESSION["logged_user_role"]) {
        case "admin":
            header('Location: mainPage.php');
            setcookie("forbiddenPage", "forbiddenPage", time() + (2));
            break;
        case "guest":
            header('Location: mainPage.php');
            setcookie("forbiddenPage", "forbiddenPage", time() + (2));
            break;
    }
}elseif(!isset($_SESSION["logged_user_role"])){
    header('Location: loginPage.php');
    setcookie("loginFirst", "loginFirst", time() + (2));
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8">
    <script src="js/jquery-1.12.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/restaurant-finder.css">
    <title>Restaurant Finder</title>
</head>
<body>
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#">Restaurant Finder</a>
        </div>
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li><a href="mainPage.php">MainPage</a></li>
                <li><a href="monitorReservations.php">Monitor Reservations</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php
                if (isset($_SESSION["logged_user_name"]) && isset($_SESSION["logged_user_email"]) && isset($_SESSION["logged_user_role"])) {
                    $personalPageLink = "#";
                    switch ($_SESSION["logged_user_role"]) {
                        case "admin":
                            $personalPageLink = "adminPage.php";
                            break;
                        case "owner":
                            $personalPageLink = "ownerPage.php";
                            break;
                        case "guest":
                            $personalPageLink = "guestPage.php";
                            break;
                    }
                    ?>
                    <li class="active">
                        <a href="<?php echo $personalPageLink; ?>"><span class="glyphicon glyphicon-user"></span>
                            Welcome <b> <?php echo $_SESSION["logged_user_name"] ?></b></a>
                    </li>
                    <li>
                        <a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Çıkış</a>
                    </li>
                    <?php
                }
                ?>
            </ul>
        </div>
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
    </div>
</nav>
<div class="container">
    <div class="container-fluid">

        <div class="page-header">
            <h2>Welcome Restaurant Owner System</h2>
        </div>

    </div>
</div>
</body>
</html>