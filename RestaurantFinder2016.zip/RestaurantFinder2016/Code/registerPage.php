<?php
include "functions.php";
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8">
    <script src="js/jquery-1.12.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/restaurant-finder.css">
    <title>Restaurant Finder</title>
</head>
<body>
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#">Restaurant Finder</a>
        </div>
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li><a href="mainPage.php">MainPage</a></li>
                <li><a href="businessPartners.php">Business Partners</a></li>
                <li><a href="joinUs.php">Join Us</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php
                if (isset($_SESSION["logged_user_name"]) && isset($_SESSION["logged_user_email"]) && isset($_SESSION["logged_user_role"])) {
                    $personalPageLink = "#";
                    switch ($_SESSION["logged_user_role"]) {
                        case "admin":
                            $personalPageLink = "adminPage.php";
                            break;
                        case "owner":
                            $personalPageLink = "ownerPage.php";
                            break;
                        case "guest":
                            $personalPageLink = "guestPage.php";
                            break;
                    }
                    ?>
                    <li>
                        <a href="<?php echo $personalPageLink; ?>"><span class="glyphicon glyphicon-user"></span>
                            Hoşgeldiniz <b> <?php echo $_SESSION["logged_user_name"] ?></b></a>
                    </li>
                    <li>
                        <a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Çıkış</a>
                    </li>
                    <?php
                } else {
                    ?>
                    <li>
                        <a href="loginPage.php"><span class="glyphicon glyphicon-log-in"></span> Login </a>
                    </li>
                    <li class="active">
                        <a href="registerPage.php"><span class="glyphicon glyphicon-edit"></span> Register </a>
                    </li>
                    <?php
                }
                ?>
            </ul>
        </div>
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
    </div>
</nav>

<div class="container">
    <div class="container-fluid">

        <?php if (isset($_COOKIE['emptyFields'])) { ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Please fill the necessary informations correctly.</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['sameMail'])) { ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>There is another account belong to this email, if you already registered you can use <a href="loginPage.php">login page</a> for entering system.</strong>
            </div>
        <?php } ?>

        <?php if (isset($_COOKIE['registerError'])) { ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Oops! Sorry something went wrong, please try again :( .</strong>
            </div>
        <?php } ?>

        <div class="row">
            <div class="col-lg-6">
                <div class="page-header h4">
                    Registration Form
                </div>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" role="form"
                      onsubmit="return passCheck()">
                    <div class="card-view">
                        <div class="form-group">
                            <label for="registerName">Name(*):</label>
                            <input required type="text" class="form-control" name="registerName" id="registerName">
                        </div>
                        <div class="form-group">
                            <label for="registerSurname">Surname(*):</label>
                            <input required type="text" class="form-control" name="registerSurname"
                                   id="registerSurname">
                        </div>
                        <div class="form-group">
                            <label for="registerPhone">Phone(*):</label>
                            <input min="0" required type="number" class="form-control" name="registerPhone" id="registerPhone">
                        </div>
                        <div class="form-group">
                            <label for="registerEmail">E-mail(*):</label>
                            <input required type="email" class="form-control" name="registerEmail" id="registerEmail">
                        </div>
                        <div class="form-group">
                            <label for="registerPass">Password(*):</label>
                            <input minlength="5" required type="password" class="form-control" name="registerPass"
                                   id="registerPass">
                        </div>
                        <div class="form-group" id="rePass">
                            <label for="registerPassRe">Re-type Password:</label>
                            <input required type="password" class="form-control" name="registerPassRe" id="registerPassRe">
                        </div>
                        <div class="form-group card-buton text-center">
                            <input type="submit" name="guestRegister" class="btn btn-primary" value="Complete Registration">
                        </div>
                    </div>
                </form>
            </div>
        </div>


    </div>
</div>

<script>
    function passCheck() {
        var pass1 = document.getElementById("registerPass").value;
        var pass2 = document.getElementById("registerPassRe").value;
        var ok = true;
        if (pass1 != pass2) {
            document.getElementById("rePass").className += ' has-error';
            ok = false;
        }
        return ok;
    }
</script>
</body>
</html>