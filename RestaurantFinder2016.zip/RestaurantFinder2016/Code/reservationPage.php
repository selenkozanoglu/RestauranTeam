<?php
include "functions.php";
session_start();
if (isset($_SESSION["logged_user_name"])) {
    if (!isset($_POST["selectedResID"])) {
        header('Location: mainPage.php');
        setcookie("selectRestaurant", "selectRestaurant", time() + (2));
    }
    if($_SESSION["logged_user_role"] != "guest"){
        header('Location: mainPage.php');
        setcookie("wrongUserType", "wrongUserType", time() + (2));
    }
} else {
    header('Location: loginPage.php');
    setcookie("pleaseLogin", "pleaseLogin", time() + (2));
}
$selectedRes = 0;
$selectedResName = "";
if (isset($_POST["selectedResID"])) {
    $selectedRes = $_POST["selectedResID"];
}
if (isset($_POST["selectedResName"])) {
    $selectedResName = $_POST["selectedResName"];
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8">
    <script src="js/jquery-1.12.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/restaurant-finder.css">
    <title>Restaurant Finder</title>
    <script>
        $(function () {
            $("#reservationDate").datepicker({ minDate: 0 });
        });
    </script>
</head>
<body>
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#">Restaurant Finder</a>
        </div>
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li><a href="mainPage.php">MainPage</a></li>
                <li><a href="businessPartners.php">Business Partners</a></li>
                <li><a href="joinUs.php">Join Us</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php
                if (isset($_SESSION["logged_user_name"]) && isset($_SESSION["logged_user_email"]) && isset($_SESSION["logged_user_role"])) {
                    $personalPageLink = "#";
                    switch ($_SESSION["logged_user_role"]) {
                        case "admin":
                            $personalPageLink = "adminPage.php";
                            break;
                        case "owner":
                            $personalPageLink = "ownerPage.php";
                            break;
                        case "guest":
                            $personalPageLink = "guestPage.php";
                            break;
                    }
                    ?>
                    <li>
                        <a href="<?php echo $personalPageLink; ?>"><span class="glyphicon glyphicon-user"></span>
                            Welcome <b> <?php echo $_SESSION["logged_user_name"] ?></b></a>
                    </li>
                    <li>
                        <a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Çıkış</a>
                    </li>
                    <?php
                } else {
                    ?>
                    <li>
                        <a href="loginPage.php"><span class="glyphicon glyphicon-log-in"></span> Login </a>
                    </li>
                    <li>
                        <a href="registerPage.php"><span class="glyphicon glyphicon-edit"></span> Register </a>
                    </li>
                    <?php
                }
                ?>
            </ul>
        </div>
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
    </div>
</nav>

<div class="container">
    <div class="container-fluid">
        <div class="page-header">
            <h2>Reservation Page</h2>
        </div>

        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="card-view">
                    <div class="h3">
                        <?php echo $selectedResName; ?>
                    </div>
                    <form action="functions.php" method="post" role="form">
                        <input type="hidden" name="restID" value="<?php echo $selectedRes; ?>">
                        <input type="hidden" name="reservationOwnerMail"
                               value="<?php echo $_SESSION["logged_user_email"]; ?>">

                        <div class="form-group">
                            <label class="pull-left" for="numberPeople">How many people:</label>
                            <input min="1" type="number" required name="numberPeople" id="numberPeople" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="pull-left" for="reservationDate">Reservation Date:</label>
                            <input readonly="readonly" type="text" required name="reservationDate" id="reservationDate" class="form-control" placeholder="Click for select date">
                        </div>
                        <div class="form-group">
                            <label class="pull-left" for="reservationTime">Reservation Time:</label>
                            <select class="form-control" name="reservationTime" id="reservationTime">
                                <option value="6">06:00 - 07:00</option>
                                <option value="7">07:00 - 08:00</option>
                                <option value="8">08:00 - 09:00</option>
                                <option value="9">09:00 - 10:00</option>
                                <option value="10">10:00 - 11:00</option>
                                <option value="11">11:00 - 12:00</option>
                                <option value="12">12:00 - 13:00</option>
                                <option value="13">13:00 - 14:00</option>
                                <option value="14">14:00 - 15:00</option>
                                <option value="15">15:00 - 16:00</option>
                                <option value="16">16:00 - 17:00</option>
                                <option value="17">17:00 - 18:00</option>
                                <option value="18">18:00 - 19:00</option>
                                <option value="19">19:00 - 20:00</option>
                                <option value="20">20:00 - 21:00</option>
                                <option value="21">21:00 - 22:00</option>
                                <option value="22">22:00 - 23:00</option>
                                <option value="23">23:00 - 24:00</option>
                                <option value="24">00:00 - 01:00</option>
                                <option value="1">01:00 - 02:00</option>
                                <option value="2">02:00 - 03:00</option>
                                <option value="3">03:00 - 04:00</option>
                                <option value="4">04:00 - 05:00</option>
                                <option value="5">05:00 - 06:00</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="pull-left" for="reservationMessage">Your Message(Optional):</label>
                            <textarea style="resize: vertical;" class="form-control" name="reservationMessage" id="reservationMessage" placeholder="You can add details or requests for your reservation.."></textarea>
                        </div>
                        <div class="form-group pull-right">
                            <input type="submit" name="completeReservation" class="btn btn-primary"
                                   value="Complete The Reservation">
                        </div>
                    </form>
                </div>
            </div>
        </div>


    </div>
</div>
</body>
</html>