-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 27 Tem 2016, 01:17:50
-- Sunucu sürümü: 5.7.9
-- PHP Sürümü: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `restaurant_finder`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `cities`
--

DROP TABLE IF EXISTS `cities`;
CREATE TABLE IF NOT EXISTS `cities` (
  `city_id` int(11) NOT NULL AUTO_INCREMENT,
  `city_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `city_plate_number` int(11) NOT NULL,
  PRIMARY KEY (`city_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `reservations`
--

DROP TABLE IF EXISTS `reservations`;
CREATE TABLE IF NOT EXISTS `reservations` (
  `reservation_id` int(11) NOT NULL AUTO_INCREMENT,
  `reservation_person_number` int(11) NOT NULL,
  `reservation_date` date NOT NULL,
  `reservation_time` int(11) NOT NULL,
  `reservation_message` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `reservation_owner` int(11) NOT NULL,
  `reservation_restaurant` int(11) NOT NULL,
  PRIMARY KEY (`reservation_id`),
  KEY `reservation_owner` (`reservation_owner`),
  KEY `reservation_restaurant` (`reservation_restaurant`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `restaurants`
--

DROP TABLE IF EXISTS `restaurants`;
CREATE TABLE IF NOT EXISTS `restaurants` (
  `restaurant_id` int(11) NOT NULL AUTO_INCREMENT,
  `restaurant_img` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `restaurant_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `restaurant_address` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `restaurant_phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `restaurant_quota` int(11) NOT NULL,
  `restaurant_owner` int(11) NOT NULL,
  `restaurant_city` int(11) NOT NULL,
  PRIMARY KEY (`restaurant_id`),
  KEY `restaurant_owner` (`restaurant_owner`),
  KEY `restaurant_city` (`restaurant_city`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Tablo döküm verisi `roles`
--

INSERT INTO `roles` (`role_id`, `role_name`) VALUES
(1, 'admin'),
(2, 'owner'),
(3, 'guest');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `status`
--

DROP TABLE IF EXISTS `status`;
CREATE TABLE IF NOT EXISTS `status` (
  `status_id` int(11) NOT NULL AUTO_INCREMENT,
  `status_name` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Tablo döküm verisi `status`
--

INSERT INTO `status` (`status_id`, `status_name`) VALUES
(1, 'accepted'),
(2, 'rejected'),
(3, 'waiting');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `user_surname` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `user_phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_pass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_role` int(11) NOT NULL,
  `user_status` int(11) NOT NULL,
  `activation_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `checkedMail` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_email` (`user_email`),
  KEY `user_role` (`user_role`),
  KEY `user_status` (`user_status`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`user_id`, `user_image`, `user_name`, `user_surname`, `user_phone`, `user_email`, `user_pass`, `user_role`, `user_status`, `activation_code`, `checkedMail`) VALUES
(1, ' ', 'Arda', 'Yazkan', '05312956458', 'ardaayazkan@gmail.com', 'c7ad19d26401e9a3dfdd396655fd3699', 1, 1, '', 0),
(2, ' ', 'Aslı Tuba', 'Metin', '05333929363', 'aslitubametin@gmail.com', '4d0372d66d4ea659c448920b282863db', 2, 1, '', 0),
(5, ' ', 'Selen', 'Kozanoğlu', '05553509336', 'kozanogluselen@gmail.com', 'b412965a05dbc32a5ee781033211e0d0', 3, 1, '', 0),
(15, '#', 'emine', 'yildiz', '05324903553', 'aslitubametin91@gmail.com', '940fb13149fa84c4673d1a80c4c0b54b', 3, 3, '0e93b7cfa6ef08c5c5ea5394f8ed323d', 0);

--
-- Dökümü yapılmış tablolar için kısıtlamalar
--

--
-- Tablo kısıtlamaları `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`reservation_owner`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`reservation_restaurant`) REFERENCES `restaurants` (`restaurant_id`);

--
-- Tablo kısıtlamaları `restaurants`
--
ALTER TABLE `restaurants`
  ADD CONSTRAINT `restaurants_ibfk_1` FOREIGN KEY (`restaurant_owner`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `restaurants_ibfk_2` FOREIGN KEY (`restaurant_city`) REFERENCES `cities` (`city_id`);

--
-- Tablo kısıtlamaları `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `user_role` FOREIGN KEY (`user_role`) REFERENCES `roles` (`role_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `user_status` FOREIGN KEY (`user_status`) REFERENCES `status` (`status_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
